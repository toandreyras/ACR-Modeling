ACR DATA PACKAGE

Processed synthetic data derivatives for the revised ACR manuscript package.
Contains corrected-formula outputs only.
