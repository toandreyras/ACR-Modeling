"""
run_all.py
Master entry point for the ACR manuscript / OSF package.
Runs ablation tests, syn-ds004024 simulation, and syn-ds006623 simulation.
"""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SCRIPTS = ROOT / 'scripts'
OUT4 = ROOT / 'syn-ds004024' / 'derivatives' / 'metrics'
OUT6 = ROOT / 'syn-ds006623' / 'derivatives' / 'metrics'

cmds = [
    [sys.executable, str(SCRIPTS / 'ablation_tests.py')],
    [sys.executable, str(SCRIPTS / 'simulate_ds004024.py'), '--out-dir', str(OUT4)],
    [sys.executable, str(SCRIPTS / 'simulate_ds006623.py'), '--out-dir', str(OUT6)],
]

for cmd in cmds:
    print('RUN:', ' '.join(cmd))
    subprocess.run(cmd, check=True)

print('All ACR package scripts completed successfully.')
